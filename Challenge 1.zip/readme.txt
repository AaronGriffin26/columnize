Source code is in src/java. Run the program from Main.main(). It works with Java 8 SDK.
It will prompt you for a file path and a number of columns. You can also provide this data as args (the program will terminate if it's wrong).
Tests are provided in src/test. They contain the supplied test data from the challenge.
Test inputs:
    Input1.txt 2
    Input2.txt 3